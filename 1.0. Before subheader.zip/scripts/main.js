document.addEventListener("DOMContentLoaded", function() {
    // Завантажуємо хедер
    const headerPlaceholder = document.getElementById('header-placeholder');
    if (headerPlaceholder) {
      console.log('Attempting to load header...');
      fetch('partials/header.html')
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
          }
          return response.text();
        })
        .then(data => {
          console.log('Header loaded successfully');
          headerPlaceholder.innerHTML = data;
        })
        .catch(error => {
          console.error('Помилка завантаження хедера:', error);
          headerPlaceholder.innerHTML = '<div style="color: red;">Error loading header: ' + error.message + '</div>';
        });
    } else {
      console.error('Header placeholder element not found');
    }
  
    // Підставляємо тексти
    if (typeof pageTexts !== "undefined") {
      const page = document.body.dataset.page; // Беремо назву сторінки із атрибута
  
      if (page && pageTexts[page]) {
        const texts = pageTexts[page];
  
        for (const [id, text] of Object.entries(texts)) {
          const el = document.getElementById(id);
          if (el) {
            if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
              el.placeholder = text;
            } else {
              el.textContent = text;
            }
          }
        }
      }
    }
  });
  
  // Дропдаун для пошуку журналу
  const searchInput = document.getElementById('searchPlaceholder');
  const dropdown = document.getElementById('dropdown');

  if (searchInput && dropdown) {
    const journalTitle = 'BMC Biology';
    const journalISSN = '1741-7007';

    searchInput.addEventListener('input', function() {
      if (this.value.trim() !== '') {
        dropdown.innerHTML = `
          <div class="dropdown-item" tabindex="0">
            <div class="dropdown-title">${journalTitle}</div>
            <div class="dropdown-issn">${journalISSN}</div>
          </div>
        `;
        dropdown.style.display = 'block';
      } else {
        dropdown.style.display = 'none';
      }
    });

    // При кліку на елемент дропдауну — підставити значення в інпут
    dropdown.addEventListener('click', function(e) {
      const item = e.target.closest('.dropdown-item');
      if (item) {
        searchInput.value = `${journalISSN}, ${journalTitle}`;
        dropdown.style.display = 'none';
      }
    });

    // При втраті фокусу ховаємо дропдаун (з затримкою для кліку)
    searchInput.addEventListener('blur', function() {
      setTimeout(() => { dropdown.style.display = 'none'; }, 150);
    });
  }
  