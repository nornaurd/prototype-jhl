/claim-prototype/
│
├── index.html
├── preview.html
├── login.html
├── signup.html
├── additional-info.html
├── checkout.html
│
├── assets/
│   └── logo.svg
│
├── partials/
│   └── header.html
│
├── styles/
│   └── style.css
│
├── scripts/
│   ├── main.js
│   └── texts.js
│
└── README.md
